from Program import *

game = Program()

game.execute()
