import pygame, os, sys
from pygame.locals import *
from Frog import *

if not pygame.mixer.get_init():
    pygame.mixer.init() # setup mixer to avoid sound lag

class Menu():
    def __init__(self, width, height):
        self.width = width
        self.height = height 
        self.frogs = []
        self.top_rect = Rect(0, 0, self.width, self.height / 2)
        self.bottom_rect = Rect(0, self.height / 2, self.width, self.height / 2)
        self.items = ["Play", "How to Play", "Quit"]
        self.item_surfaces = []
        self.item_rects    = []
        self.howToPlay = ["Press escape to return to the menu", "Arrow keys = move", "p = pause", "Goal:", "Get 5 frogs to the blue holes at the top", "of the screen without dying!"]
        self.howToPlaySurfaces = []
        self.howToPlayShown = False
        self.last_frog = -1
        self.frog_changed = False
        self.open = True 
        self.background_music = pygame.mixer.Sound(os.path.join('sounds', 'froggermain.ogg'))
        self.font = pygame.font.Font(os.path.join('fonts', "FreeMonoBold.ttf"), 42)
        self.howToFont = pygame.font.Font(os.path.join('fonts', 'FreeMonoBold.ttf'), 22)
        self.letter_surfaces = []
        self.letters = -1
        self.coins   = 0

        startY = self.height / 2 + 20

        for i in range(7):
            self.letter_surfaces.append(self.font.render("FROGGER"[i], True, (155, 255, 155)))

        for i in self.items:
            self.item_surfaces.append(self.font.render(i, True, (155, 255, 155)))

        for i in range(len(self.items)):
            self.item_rects.append(Rect(self.width / 2 - self.item_surfaces[i].get_rect().width / 2, startY, 
                                        self.item_surfaces[i].get_rect().width, self.item_surfaces[i].get_rect().height))
            startY += 100

        for i in range(7):
            frog = Frog(os.path.join('images', "frog_sprites_big.png"))
            frog.image.set_colorkey((0, 0, 0))

            # standing
            frog.clips.append(Rect(120, 0, 35, 26))
            # mid-jump
            frog.clips.append(Rect(62,  0, 26, 35))
            # full jump
            frog.clips.append(Rect(0,   0, 30, 33))

            frog.setPos((i + 1) * 65, self.height + frog.rect.height)
            # print frog.rect 

            self.frogs.append(frog)

            self.background_music.play()

        for i in self.howToPlay:
            self.howToPlaySurfaces.append(self.howToFont.render(i, True, (155, 255, 155)))

    def stopMusic(self):
        self.background_music.stop()

    def is_open(self):
        return self.open 

    def update(self):
        for i in range(len(self.frogs)):
            self.frogs[i].update(pygame.time.get_ticks())
            
            if self.last_frog == -1:
                self.frogs[i].move(0, -2)

            if self.frogs[i].rect.top <= self.height / 5 - self.frogs[i].rect.height / 2 and not self.frog_changed:
                self.last_frog += 1
                self.frog_changed = True 

    def draw(self):
        pygame.draw.rect(pygame.display.get_surface(), (0, 0, 73), self.top_rect)
        pygame.draw.rect(pygame.display.get_surface(), (0, 0, 0), self.bottom_rect)

        # startY = 100
        # for i in self.item_surfaces:
        #     pygame.display.get_surface().blit(i, (self.width / 2 - i.get_rect().width / 2, startY))
        #     startY += 80
        i = 0

        for i in range(self.letters):
            pygame.display.get_surface().blit(self.letter_surfaces[i], self.frogs[i].rect)

        if self.letters != len(self.frogs):
            while i < len(self.frogs):
                if self.frog_changed:
                    self.letters += 1
                    if self.letters > len(self.frogs):
                        self.letters -= 1 
                    self.frogs[i].is_alive = False  
                    self.frog_changed = False 
                else:
                    if self.frogs[i].is_alive:
                        self.frogs[i].draw()
                i += 1 

        if self.letters == len(self.frogs):
            startY = self.height / 2 + 20

            if not self.howToPlayShown:
                for i in range(len(self.item_surfaces)):
                    pygame.display.get_surface().blit(self.item_surfaces[i], self.item_rects[i])
            else:
                for i in range(len(self.howToPlaySurfaces)):
                    pygame.display.get_surface().blit(self.howToPlaySurfaces[i], (self.width / 2 - self.howToPlaySurfaces[i].get_rect().width / 2, startY))
                    startY += 50

    def handleInput(self, event):
        if event.type == MOUSEBUTTONDOWN:
            if self.item_rects[0].collidepoint(pygame.mouse.get_pos()):
                self.open = False 

            if self.item_rects[1].collidepoint(pygame.mouse.get_pos()):
                self.howToPlayShown = True 

            if self.item_rects[2].collidepoint(pygame.mouse.get_pos()):
                sys.exit()

        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                self.howToPlayShown = False 
